import React, { useState } from 'react';
import { register, login, logout } from './api';

export function RegisterModal({ show, onClose }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (password !== confirm) {
      setError('Passwords do not match');
      return;
    }
    const res = await register({ name, email, password, password_confirmation: confirm });
    if (res.errors || res.error) {
      setError(res.message || 'Registration failed');
    } else {
      onClose();
    }
  };

  return (
    <div className={`modal fade${show ? ' show d-block' : ''}`} tabIndex="-1" style={{ background: show ? 'rgba(0,0,0,0.5)' : 'none' }}>
      <div className="modal-dialog">
        <div className="modal-content" style={{ background: '#fff', color: '#222', borderRadius: 16, boxShadow: '0 4px 24px rgba(0,0,0,0.12)' }}>
          <div className="modal-header" style={{ borderBottom: '1px solid #eee', background: 'transparent', color: '#222' }}>
            <h5 className="modal-title">Register</h5>
            <button type="button" className="btn-close" onClick={onClose}></button>
          </div>
          <div className="modal-body">
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label" style={{ color: '#222', textAlign: 'left', display: 'block' }}>Name</label>
                <input type="text" className="form-control" required style={{ border: '1px solid #bbb', borderRadius: 6 }} value={name} onChange={e => setName(e.target.value)} />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ color: '#222', textAlign: 'left', display: 'block' }}>Email address</label>
                <input type="email" className="form-control" required style={{ border: '1px solid #bbb', borderRadius: 6 }} value={email} onChange={e => setEmail(e.target.value)} />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ color: '#222', textAlign: 'left', display: 'block' }}>Password</label>
                <input type="password" className="form-control" required style={{ border: '1px solid #bbb', borderRadius: 6 }} value={password} onChange={e => setPassword(e.target.value)} />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ color: '#222', textAlign: 'left', display: 'block' }}>Confirm Password</label>
                <input type="password" className="form-control" required style={{ border: '1px solid #bbb', borderRadius: 6 }} value={confirm} onChange={e => setConfirm(e.target.value)} />
              </div>
              {error && <div className="alert alert-danger">{error}</div>}
              <button type="submit" className="btn btn-primary w-100">Register</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export function LoginModal({ show, onClose }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const res = await login({ email, password });
    if (res.errors || res.error) {
      setError(res.message || 'Login failed');
    } else {
      onClose();
      window.location.reload(); // reload to update auth state
    }
  };

  return (
    <div className={`modal fade${show ? ' show d-block' : ''}`} tabIndex="-1" style={{ background: show ? 'rgba(0,0,0,0.5)' : 'none' }}>
      <div className="modal-dialog">
        <div className="modal-content" style={{ background: '#fff', color: '#222', borderRadius: 16, boxShadow: '0 4px 24px rgba(0,0,0,0.12)' }}>
          <div className="modal-header" style={{ borderBottom: '1px solid #eee', background: 'transparent', color: '#222' }}>
            <h5 className="modal-title">Login</h5>
            <button type="button" className="btn-close" onClick={onClose}></button>
          </div>
          <div className="modal-body">
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label" style={{ color: '#222', textAlign: 'left', display: 'block' }}>Email address</label>
                <input type="email" className="form-control" required style={{ border: '1px solid #bbb', borderRadius: 6 }} value={email} onChange={e => setEmail(e.target.value)} />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ color: '#222', textAlign: 'left', display: 'block' }}>Password</label>
                <input type="password" className="form-control" required style={{ border: '1px solid #bbb', borderRadius: 6 }} value={password} onChange={e => setPassword(e.target.value)} />
              </div>
              {error && <div className="alert alert-danger">{error}</div>}
              <button type="submit" className="btn btn-primary w-100">Login</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export function LogoutModal({ show, onClose, onLogout }) {
  const handleLogout = async () => {
    await logout();
    onLogout();
  };
  return (
    <div className={`modal fade${show ? ' show d-block' : ''}`} tabIndex="-1" style={{ background: show ? 'rgba(0,0,0,0.5)' : 'none' }}>
      <div className="modal-dialog">
        <div className="modal-content" style={{ background: '#fff', color: '#222', borderRadius: 16, boxShadow: '0 4px 24px rgba(0,0,0,0.12)' }}>
          <div className="modal-header" style={{ borderBottom: '1px solid #eee', background: 'transparent', color: '#222' }}>
            <h5 className="modal-title">Logout</h5>
            <button type="button" className="btn-close" onClick={onClose}></button>
          </div>
          <div className="modal-body">
            <p>Are you sure you want to logout?</p>
            <button className="btn btn-danger w-100" onClick={handleLogout}>Logout</button>
          </div>
        </div>
      </div>
    </div>
  );
}

const BASE_URL = "http://127.0.0.1:8000/api/";

function getToken() {
    return localStorage.getItem("auth_token");
}

function setToken(token) {
    localStorage.setItem("auth_token", token);
}

function removeToken() {
    localStorage.removeItem("auth_token");
}

async function register(data) {
    const res = await fetch(BASE_URL + "register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
    });
    return res.json();
}

async function login(data) {
    const res = await fetch(BASE_URL + "login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
    });
    const result = await res.json();
    if (result.auth_token) setToken(result.auth_token);
    else if (result.token) setToken(result.token);
    return result;
}

async function logout() {
    const res = await fetch(BASE_URL + "logout", {
        method: "POST",
        headers: {
            Authorization: "Bearer " + getToken(),
            "Content-Type": "application/json",
        },
    });
    removeToken();
    return res.json();
}

async function getProfile() {
    const res = await fetch(BASE_URL + "profile", {
        headers: { Authorization: "Bearer " + getToken() },
    });
    return res.json();
}

async function getQuotes() {
    const res = await fetch(BASE_URL + "quotes", {
        headers: { Authorization: "Bearer " + getToken() },
    });
    return res.json();
}

async function getRandomQuote() {
    const res = await fetch(BASE_URL + "quotes/random", {
        headers: { Authorization: "Bearer " + getToken() },
    });
    return res.json();
}

async function createQuote(data) {
    const res = await fetch(BASE_URL + "quotes", {
        method: "POST",
        headers: {
            Authorization: "Bearer " + getToken(),
            "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
    });
    return res.json();
}

async function deleteQuote(id) {
    const res = await fetch(BASE_URL + "quotes/" + id, {
        method: "DELETE",
        headers: { Authorization: "Bearer " + getToken() },
    });
    return res.json();
}

async function getQuote(id) {
    const res = await fetch(BASE_URL + "quotes/" + id, {
        headers: { Authorization: "Bearer " + getToken() },
    });
    return res.json();
}

export {
    register,
    login,
    logout,
    getProfile,
    getQuotes,
    getRandomQuote,
    createQuote,
    deleteQuote,
    getQuote,
    getToken,
    setToken,
    removeToken,
};

import React, { useState, useEffect } from 'react';
import './App.css';
import { RegisterModal, LoginModal, LogoutModal } from './AuthModals';
import { getToken, getRandomQuote } from './api';

function FlyingLettersBackground() {
  // Letters in various languages
  const letters = [
    'A', 'Б', 'ج', '字', 'あ', 'Ω', 'क', 'א', 'ا', '한', 'Δ', 'Ж', 'ש', 'م', 'Σ', 'Ж', 'Q', 'Z', 'Я', 'Ψ', 'Ü', 'Ç', 'Ñ', 'Ł', 'Ø', 'Æ', 'ß', 'Ω', 'π', 'λ', 'ς', 'ש', 'م', '字', 'あ', 'क', 'א', 'Ω', 'Ü', 'Ç', 'Ñ', 'Ł', 'Ø', 'Æ', 'ß', 'Ω', 'π', 'λ', 'ς'
  ];
  // Generate random positions and animation delays
  return (
    <div className="flying-letters-bg">
      {letters.map((char, i) => (
        <span
          key={i}
          className="flying-letter"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 20}s`,
            fontSize: `${2 + Math.random() * 3}rem`,
          }}
        >
          {char}
        </span>
      ))}
    </div>
  );
}

function App() {
  const [showRegister, setShowRegister] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [showLogout, setShowLogout] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(!!getToken());
  const [quote, setQuote] = useState('');
  const [author, setAuthor] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Listen for custom auth events
    const handler = () => setIsAuthenticated(!!getToken());
    window.addEventListener('authChange', handler);
    return () => window.removeEventListener('authChange', handler);
  }, []);

  const handleLogout = () => {
    setIsAuthenticated(false);
    setShowLogout(false);
    setQuote('');
    setAuthor('');
    window.dispatchEvent(new Event('authChange'));
  };

  const handleLoginOrRegister = () => {
    setShowLogin(false);
    setShowRegister(false);
    setIsAuthenticated(!!getToken());
    window.dispatchEvent(new Event('authChange'));
  };

  const handleGenerateQuote = async (e) => {
    e.preventDefault();
    setError('');
    if (!getToken()) {
      setError('You must be logged in to generate a random quote.');
      setQuote('');
      setAuthor('');
      return;
    }
    setLoading(true);
    try {
      const res = await getRandomQuote();
      if (res && (res.text || res.quote)) {
        setQuote(res.text || res.quote);
        setAuthor(res.author || '');
      } else {
        setQuote('No quote found.');
        setAuthor('');
      }
    } catch (err) {
      setError(err?.message || String(err));
      setQuote('');
      setAuthor('');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!quote) return;
    let text = quote;
    if (author) text += `\n- ${author}`;
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    });
  };

  return (
    <div className="App dark-theme">
      <FlyingLettersBackground />
      {/* Navbar */}
      <nav className="navbar">
        <div className="navbar-logo">
          {/* You can replace this with an SVG or image if you want */}
          <span role="img" aria-label="quote" className="logo-icon">“”</span>
          <span className="navbar-title">Quote Generator</span>
        </div>
        <div className="navbar-auth">
          {!isAuthenticated ? (
            <>
              <button className="btn btn-primary me-2" onClick={() => setShowLogin(true)}>Login</button>
              <button className="btn btn-secondary" onClick={() => setShowRegister(true)}>Register</button>
            </>
          ) : (
            <button className="btn btn-danger" onClick={() => setShowLogout(true)}>Logout</button>
          )}
        </div>
      </nav>
      {/* Hero Section */}
      <section className="hero-section">
        <h1 className="hero-title">Quote Generator</h1>
        <div className="quote-box">
          {loading ? (
            <span className="spinner"></span>
          ) : (
            <div style={{width: '100%'}}>
              <span className="quote-text">{quote || 'Your quote will appear here.'}</span>
              {author && (
                <div className="quote-author">- {author}</div>
              )}
            </div>
          )}
        </div>
        {error && <div className="alert alert-danger mt-2">{error}</div>}
        <div className="action-row">
          <button className="btn btn-success generate-btn" onClick={handleGenerateQuote} disabled={loading}>
            {loading ? 'Loading...' : 'Generate'}
          </button>
          <button className="btn btn-success copy-btn" onClick={handleCopy} disabled={!quote || loading} title="Copy to clipboard">
            {copied ? 'Copied!' : 'Copy'}
          </button>
        </div>
      </section>
      <RegisterModal show={showRegister} onClose={handleLoginOrRegister} />
      <LoginModal show={showLogin} onClose={handleLoginOrRegister} />
      <LogoutModal show={showLogout} onClose={() => setShowLogout(false)} onLogout={handleLogout} />
    </div>
  );
}

export default App;

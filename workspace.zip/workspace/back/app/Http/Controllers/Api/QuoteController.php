<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Quote;

class QuoteController extends Controller
{
    public function index(Request $request)
    {
        return Quote::all();
    }

    public function random()
    {
        return Quote::inRandomOrder()->first();
    }

    public function show($id)
    {
        $quote = Quote::findOrFail($id);
        return response()->json($quote);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'quote' => 'required|string',
            'author' => 'nullable|string|max:255',
            'category' => 'nullable|string|max:100',
        ]);

        $quote = Quote::create($validated);
        return response()->json($quote, 201);
    }

    public function destroy($id)
    {
        $quote = Quote::findOrFail($id);
        $quote->delete();
        return response()->json(['message' => 'Quote deleted successfully']);
    }
}
